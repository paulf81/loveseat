/*---------------------------------------------------------------------------*\
  =========                 |
  \\      /  F ield         | OpenFOAM: The Open Source CFD Toolbox
   \\    /   O peration     |
    \\  /    A nd           | Copyright (C) 2011 OpenFOAM Foundation
     \\/     M anipulation  |
-------------------------------------------------------------------------------
License
    This file is part of OpenFOAM.

    OpenFOAM is free software: you can redistribute it and/or modify it
    under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    OpenFOAM is distributed in the hope that it will be useful, but WITHOUT
    ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
    FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License
    for more details.

    You should have received a copy of the GNU General Public License
    along with OpenFOAM.  If not, see <http://www.gnu.org/licenses/>.

\*---------------------------------------------------------------------------*/

#include "wallDist.H"
#include "patchWave.H"
#include "fvMesh.H"
#include "wallPolyPatch.H"
#include "fvPatchField.H"
#include "Field.H"
#include "emptyFvPatchFields.H"
#include "wallFvPatch.H"


// * * * * * * * * * * * * * Private Member Functions  * * * * * * * * * * * //


// Calculate the normal vector from a three-point plane
Foam::vector Foam::wallDist::planeNormal
(
    const point& A,
    const point& B,
    const point& C
)
{
    vector normal;

    scalar vx = (B.x() - C.x());
    scalar vy = (B.y() - C.y());
    scalar vz = (B.z() - C.z());

    scalar wx = (A.x() - B.x());
    scalar wy = (A.y() - B.y());
    scalar wz = (A.z() - B.z());

    scalar vw_x = vy * wz - vz * wy;
    scalar vw_y = vz * wx - vx * wz;
    scalar vw_z = vx * wy - vy * wx;

    scalar magitude = Foam::sqrt((vw_x * vw_x) + (vw_y * vw_y) + (vw_z * vw_z));

    scalar CA = 0;
    scalar CB = 0;
    scalar CC = 0;
    // scalar CD;
    if ( magitude > SMALL )
    {
        magitude = 1/magitude; // compute the recipricol distance

        CA = vw_x * magitude;
        CB = vw_y * magitude;
        CC = vw_z * magitude;
        // CD = 0.0 - ((CA*A.x())+(CB*A.y())+(CC*A.z()));
    }

    normal.x() = CA;
    normal.y() = CB;
    normal.z() = CC;

    return normal;
}


// Find the index of the vector that has the max of components
Foam::label Foam::wallDist::maxCompIndex(const vector& V)
{
    scalar maxComp = -VGREAT;
    label index = 0;
    forAll(V,i)
    {
        if (maxComp < mag(V[i]))
        {
            maxComp = mag(V[i]);
            index = i;
        }
    }
    return index;
}


Foam::scalar Foam::wallDist::hitDist
(
    const point& shootPt,
    const pointField& polygonPts
)
{
    vector normal = planeNormal(polygonPts[0],polygonPts[1],polygonPts[2]);

    point A = polygonPts[0];
    scalar CA = normal.x();
    scalar CB = normal.y();
    scalar CC = normal.z();
    scalar CD = 0.0 - ((CA*A.x())+(CB*A.y())+(CC*A.z()));

    scalar distance =
        mag(CA*shootPt.x()+CB*shootPt.y()+CC*shootPt.z()+CD)
      / Foam::sqrt(CA*CA+CB*CB+CC*CC);

    return distance;
}


Foam::point Foam::wallDist::hitPoint
(
    const point& shootPt,
    const pointField& polygonPts
)
{
    // The projection of a point q = (x, y, z) onto a plane given by
    // a point p = (a, b, c) and a normal n = (d, e, f) is:
    // q_proj = q - dot(q - p, n) * n
    vector normal = planeNormal(polygonPts[0],polygonPts[1],polygonPts[2]);

    return shootPt - ((shootPt - polygonPts[0]) & normal) * normal;
}


// Judge if a spacial point's projection is in a line region
// If it is on the line, then return the distance, if not return -1
Foam::scalar Foam::wallDist::ptInLine
(
    const point& shootPt,
    const point& es,
    const point& ee
)
{
    vector A = shootPt-es;
    vector B = ee-es;
    scalar projLen = mag(A)*(A & B)/(mag(A)*mag(B));
    if (projLen <= mag(B) && projLen > 0)
    {
        return Foam::sqrt(mag(A)*mag(A)-projLen*projLen);
    }
    else
    {
        return -1.0;
    }

}

// isLeft(): tests if a point is Left|On|Right of an infinite line.
//    Input: three points P0, P1, and P2
//   Return: >0 for P2 left of the line through P0 and P1
//           =0 for P2 on the line
//           <0 for P2 right of the line
//      See: Algorithm 1 "Area of Triangles and Polygons"
bool Foam::wallDist::isLeft(const point& P0, const point& P1, const point& P2)
{
    if (mag(P1.x()-P0.x()) < VSMALL)
    {
        if (mag(P2.x()-P0.x()) < VSMALL)
        {
            // Info<< "P0 = " << P0 << tab
            //     << "P1 = " << P1 << tab
            //     << "P2 = " << P2 << tab
            //     << endl;
            return true;
        }

        if (P1.y() > P0.y())
        {
            if (P2.x() > P0.x())
            {
                return false;
            }
            else
            {
                return true;
            }
        }
        else
        {
            if (P2.x() > P0.x())
            {
                return true;
            }
            else
            {
                return false;
            }
        }
    }
    else if (mag(P1.y()-P0.y()) < VSMALL)
    {
        if (mag(P2.y()-P0.y()) < VSMALL)
        {
            // Info<< "P0 = " << P0 << tab
            //     << "P1 = " << P1 << tab
            //     << "P2 = " << P2 << tab
            //     << endl;
            return true;
        }

        if (P1.x() > P0.x())
        {
            if (P2.y() > P0.x())
            {
                return true;
            }
            else
            {
                return false;
            }
        }
        else
        {
            if (P2.y() > P0.x())
            {
                return false;
            }
            else
            {
                return true;
            }
        }
    }
    else
    {
        scalar aaa = P1.x() - P0.x();
        scalar bbb = P2.y() - P0.y();
        scalar ccc = P2.x() - P0.x();
        scalar ddd = P1.y() - P0.y();
        scalar DET = aaa*bbb-ccc*ddd;

        if (pos(DET))
        {
            return true;
        }
        else if (neg(DET))
        {
            return false;
        }
        else
        {
            // Info<< "P0 = " << P0 << tab
            //     << "P1 = " << P1 << tab
            //     << "P2 = " << P2 << tab
            //     << "DET = " << DET << tab
            //     << endl;
            // FatalErrorIn("isLeft")
            //     << "Three points in one line!!! DET ZERO"
            //     << Foam::abort(FatalError);
            return true;
        }
    }
}


// wnPnPoly(): winding number test for a point in a polygon
//      Input: P = a point,
//             V[] = vertex points of a polygon V[n+1] with V[n]=V[0]
//     Return: wn = the winding number (=0 only when P is outside)
// Note: The shootPt must be in the same plane as polygonPts
//       And then let the component to be dropped be automatically decided.
bool Foam::wallDist::wnPnPoly
(
    const point& shootPt,
    const pointField& polygonPts
)
{
    // Info<< "shootPt = " << shootPt << tab
    //     << "polygonPts = " << polygonPts << tab
    //     << "normal = " << planeNormal(polygonPts[0],polygonPts[1],polygonPts[2]) << tab
    //     << endl;
    // Initialize the winding number counter and others
    bool inPoly = 0;
    label wn = 0;
    label compDropped = maxCompIndex
    (
        planeNormal(polygonPts[0],polygonPts[1],polygonPts[2])
    );
    pointField V(polygonPts.size());
    point P;

    switch (compDropped)
    {
        case 0:
            P.x() = shootPt.y();
            P.y() = shootPt.z();
            P.z() = shootPt.x();
            break;
        case 1:
            P.x() = shootPt.x();
            P.y() = shootPt.z();
            P.z() = shootPt.y();
            break;
        case 2:
            P.x() = shootPt.x();
            P.y() = shootPt.y();
            P.z() = shootPt.z();
            break;
        default :
            WarningIn("wnPnPoly")
                << "Default is to drop the z component!"
                << endl;
            P.x() = shootPt.x();
            P.y() = shootPt.y();
            P.z() = shootPt.z();
    }

    for (label i = 0; i < V.size(); i++)
    {
        switch (compDropped)
        {
            case 0:
                V[i].x() = polygonPts[i].y();
                V[i].y() = polygonPts[i].z();
                V[i].z() = polygonPts[i].x();
                break;
            case 1:
                V[i].x() = polygonPts[i].x();
                V[i].y() = polygonPts[i].z();
                V[i].z() = polygonPts[i].y();
                break;
            case 2:
                V[i].x() = polygonPts[i].x();
                V[i].y() = polygonPts[i].y();
                V[i].z() = polygonPts[i].z();
                break;
            default :
                // Default is to drop the z component
                V[i].x() = polygonPts[i].x();
                V[i].y() = polygonPts[i].y();
                V[i].z() = polygonPts[i].z();
        }
    }

    // Append V list so that V[n] now becomes V[n+1] with V[n]=V[0]
    label VN = V.size();
    V.resize(VN+1);
    V[VN] = V[0];

    // Loop through all edges of the polygon
    // Edge from V[i] to V[i+1]
    for (label i = 0; i < V.size(); i++)
    {
        label pre = i;
        label nxt = i+1;
        if (nxt == V.size())
        {
            nxt = 0;
        }
        // Start y <= P.y
        if (V[pre].y() <= P.y())
        {
            // An upward crossing
            if (V[nxt].y() > P.y())
            {
                // P left of edge
                if (isLeft(V[pre], V[nxt], P))
                {
                    // Have a valid up intersect
                    ++wn;
                }
            }
        }
        else
        {
            // Start y > P.y (no test needed)
            // A downward crossing
            if (V[nxt].y() <= P.y())
            {
                // P right of edge
                if (!isLeft(V[pre], V[nxt], P))
                {
                    // Have a valid down intersect
                    --wn;
                }
            }
        }
    }

    wn = mag(wn);
    switch (wn)
    {
        case 0: inPoly = 0; break;
        case 1: inPoly = 1; break;
        default: FatalErrorIn("wnPnPoly")
            << "How could winding number be negative? Double check please!"
            << Foam::abort(FatalError);
    }

    return inPoly;
}


Foam::label Foam::wallDist::minDistPtID
(
    const point& shootPt,
    const pointField& wallPts
)
{
    scalar minValue = VGREAT;
    label minPtID = 0;
    forAll(wallPts, pointI)
    {
        scalar dist = mag(wallPts[pointI]-shootPt);
        if (dist < minValue)
        {
            minValue = dist;
            minPtID = pointI;
        }
    }

    return minPtID;
}


// * * * * * * * * * * * * * * * * Constructors  * * * * * * * * * * * * * * //

Foam::wallDist::wallDist(const fvMesh& mesh, const bool correctWalls)
:
    volScalarField
    (
        IOobject
        (
            "y",
            mesh.time().timeName(),
            mesh
        ),
        mesh,
        dimensionedScalar("y", dimLength, GREAT)
    ),
    cellDistFuncs(mesh),
    correctWalls_(correctWalls),
    nUnset_(0)
{
    wallDist::correct();
}


// * * * * * * * * * * * * * * * * Destructor  * * * * * * * * * * * * * * * //

Foam::wallDist::~wallDist()
{}


// * * * * * * * * * * * * * * * Member Functions  * * * * * * * * * * * * * //

// Correct for mesh geom/topo changes. Might be more intelligent in the
// future (if only small topology change)
void Foam::wallDist::correct()
{
    // // Get patchids of walls
    // labelHashSet wallPatchIDs(getPatchIDs<wallPolyPatch>());

    // // Calculate distance starting from wallPatch faces.
    // patchWave wave(cellDistFuncs::mesh(), wallPatchIDs, correctWalls_);

    // // Transfer cell values from wave into *this
    // transfer(wave.distance());

    // // Transfer values on patches into boundaryField of *this
    // forAll(boundaryField(), patchI)
    // {
    //     if (!isA<emptyFvPatchScalarField>(boundaryField()[patchI]))
    //     {
    //         scalarField& waveFld = wave.patchDistance()[patchI];

    //         boundaryField()[patchI].transfer(waveFld);
    //     }
    // }

    // // Transfer number of unset values
    // nUnset_ = wave.nUnset();


    //
    // Calculate the true distance using my own algorithm
    //
    Info<< "Using the New Wall Distance Algorithm!!" << endl;

    // Collect all wall points, wall edges and wall faces
    // It will be better if PrimitivePatch class has localEdges and localFaces
    fvMesh mesh(cellDistFuncs::mesh());
    const fvPatchList& patches = mesh.boundary();

    List<pointField> wallPts(Pstream::nProcs());
    List<List<pointField> > wallEdges(Pstream::nProcs());
    List<List<pointField> > wallFaces(Pstream::nProcs());
    forAll(patches, patchI)
    {
        const fvPatch& currPatch = patches[patchI];

        if (isA<wallFvPatch>(currPatch))
        {
            Info<< "Wall Patch : " << currPatch.name() << endl;
            pointField wallPtsCur = currPatch.patch().localPoints();
            edgeList wallEdgesTmpList = currPatch.patch().edges();
            List<pointField> wallEdgesCur(wallEdgesTmpList.size());
            forAll(wallEdgesTmpList,edgeI)
            {
                forAll(wallEdgesTmpList[edgeI],pointI)
                {
                    wallEdgesCur[edgeI].append
                    (
                        currPatch.patch().localPoints()
                        [
                            wallEdgesTmpList[edgeI][pointI]
                        ]
                    );
                }
            }
            faceList wallFacesTmpList = currPatch.patch().localFaces();
            List<pointField> wallFacesCur(wallFacesTmpList.size());
            forAll(wallFacesTmpList,faceI)
            {
                forAll(wallFacesTmpList[faceI],pointI)
                {
                    wallFacesCur[faceI].append
                    (
                        currPatch.patch().localPoints()
                        [
                            wallFacesTmpList[faceI][pointI]
                        ]
                    );
                }
            }

            wallPts[Pstream::myProcNo()].append(wallPtsCur);
            wallEdges[Pstream::myProcNo()].append(wallEdgesCur);
            wallFaces[Pstream::myProcNo()].append(wallFacesCur);
        }
    }

    Pstream::gatherList(wallPts);
    Pstream::gatherList(wallEdges);
    Pstream::gatherList(wallFaces);
    Pstream::scatterList(wallPts);
    Pstream::scatterList(wallEdges);
    Pstream::scatterList(wallFaces);

    // Info<< "wallEdges = " << wallEdges << endl;

    //-For Debug usage
    //----------------
    // for (label procI = 0; procI < Pstream::nProcs(); ++procI)
    // {
    //     // Info<< "wallPts[procI] = " << wallPts[procI] << endl;
    //     // Info<< "wallEdges[procI] = " << wallEdges[procI] << endl;
    //     forAll(wallEdges[procI],edgeI)
    //     {
    //         Info<< "["
    //             << mesh.points()[wallEdges[procI][edgeI][0]]
    //             << ","
    //             << mesh.points()[wallEdges[procI][edgeI][1]]
    //             << "]"
    //             << endl;
    //     }
    //     // forAll(wallFaces[procI],faceI)
    //     // {
    //     //     face wallFace = wallFaces[procI][faceI];
    //     //     pointField facePts(wallFace.size());
    //     //     forAll(facePts,facePtsI)
    //     //     {
    //     //         facePts[facePtsI] = mesh.points()[wallFace[facePtsI]];
    //     //     }
    //     //     Info<< "[" << procI << "]facePts = " << facePts << endl;
    //     // }
    // }


    scalarField trueDistance(mesh.C().size(),scalar(0.0));
    // Step-1: Seek the minimum distance to the wall faces whenever applicable
    forAll(mesh.C(), cellI)
    {
        // Info<< "mesh.C() = " << setprecision(12) << mesh.C()[cellI] << endl;
        point shootPt = mesh.C()[cellI];
        scalar minCCToWallDist = VGREAT;
        bool touched = 0;
        for (label procI = 0; procI < Pstream::nProcs(); ++procI)
        {
            if (wallFaces[procI].size() != 0)
            {
                forAll(wallFaces[procI],faceI)
                {
                    pointField facePts = wallFaces[procI][faceI];

                    if (wnPnPoly(hitPoint(shootPt,facePts),facePts))
                    {
                        scalar thisDist = hitDist(shootPt,facePts);
                        if (thisDist < minCCToWallDist)
                        {
                            minCCToWallDist = thisDist;
                            touched = 1;
                        }
                    }
                }
            }
        }
        // Use touched to prevent trueDistance[cellI] = minCCToWallDist,
        // Where minCCToWallDist is still VGREAT
        if (touched)
        {
            trueDistance[cellI] = minCCToWallDist;
            // trueDistance[cellI] = mag(mesh.C()[cellI]);
            // Info<< "point["
            //     << shootPt
            //     << "] trueDistance corrected by Step-1!"
            //     << endl;
        }
    }

    // Step-2: If step-1 is not applicable, 
    // then seek the minimum distance to the wall lines whenever applicable
    forAll(mesh.C(), cellI)
    {
        // The untouched trueDistance in cellI should be zero,
        // but I am afraid there would be little disturbances somewhere,
        // so "trueDistance[cellI] < VSMALL" is used here.
        if (trueDistance[cellI] == 0 || trueDistance[cellI] != 0)
        {
            point shootPt = mesh.C()[cellI];
            scalar minCCToWallDist = VGREAT;
            if (trueDistance[cellI] != 0)
            {
                minCCToWallDist = trueDistance[cellI];
            }
            bool touched = 0;
            for (label procI = 0; procI < Pstream::nProcs(); ++procI)
            {
                if (wallEdges[procI].size() != 0)
                {
                    forAll(wallEdges[procI],edgeI)
                    {
                        scalar tmpDist = ptInLine
                        (
                            shootPt,
                            wallEdges[procI][edgeI][0],
                            wallEdges[procI][edgeI][1]
                        );
                        if
                        (
                            (tmpDist != -1.0)
                         && (tmpDist < minCCToWallDist)
                        )
                        {
                            minCCToWallDist = tmpDist;
                            touched = 1;
                        }
                    }
                }
            }
            // Use touched to prevent trueDistance[cellI] = minCCToWallDist,
            // Where minCCToWallDist is still VGREAT
            if (touched)
            {
                trueDistance[cellI] = minCCToWallDist;
                // Info<< "point["
                //     << shootPt
                //     << "] trueDistance corrected by Step-2! -- "
                //     << minCCToWallDist
                //     << endl;
            }
        }
    }

    // // Step-3: If step-1 and step-2 are not applicable, 
    // // then seek the minimum distance to the wall points whenever applicable
    forAll(mesh.C(), cellI)
    {
        if (trueDistance[cellI] == 0 || trueDistance[cellI] != 0)
        {
            point shootPt = mesh.C()[cellI];
            scalar minCCToWallDist = VGREAT;
            if (trueDistance[cellI] != 0)
            {
                minCCToWallDist = trueDistance[cellI];
            }
            for (label procI = 0; procI < Pstream::nProcs(); ++procI)
            {
                if (wallPts[procI].size() != 0)
                {
                    label minPtID = minDistPtID(shootPt,wallPts[procI]);
                    // Info<< "minPtID = "
                    //     << minPtID
                    //     << endl;
                    point minPt = wallPts[procI][minPtID];
                    if (mag(shootPt-minPt) < minCCToWallDist)
                    {
                        minCCToWallDist = mag(shootPt-minPt);
                    }
                }
            }
            trueDistance[cellI] = minCCToWallDist;
            // Info<< "point["
            //     << shootPt
            //     << "] trueDistance corrected by Step-3!"
            //     << endl;
        }
    }

    transfer(trueDistance);


    // Calculation wall distance of the points on patches
    forAll(patches, patchI)
    {
        const fvPatch& currPatch = patches[patchI];

        if (currPatch.size() != 0)
        {
            if (isA<wallFvPatch>(currPatch))
            {
                scalarField zeroField(currPatch.size(),scalar(1e-15));
                boundaryField()[patchI].transfer(zeroField);
            }
            else if (!isA<emptyFvPatch>(currPatch))
            {
                scalarField curField(currPatch.size(),scalar(0.0));

                forAll(currPatch.patch().faceCentres(), ptI)
                {
                    point shootPt = currPatch.patch().faceCentres()[ptI];

                    scalar minPatchToWallDist = VGREAT;
                    // Identify those patch points that are also on the wall
                    for (label procI = 0; procI < Pstream::nProcs(); ++procI)
                    {
                        if (wallPts[procI].size() != 0)
                        {
                            label minPtID = minDistPtID(shootPt,wallPts[procI]);
                            point minPt = wallPts[procI][minPtID];
                            if (mag(shootPt-minPt) < minPatchToWallDist)
                            {
                                minPatchToWallDist = mag(shootPt-minPt);
                                // Info<< "minPatchToWallDist = "
                                //     << minPatchToWallDist
                                //     << endl;
                            }
                        }
                    }

                    if (minPatchToWallDist < VSMALL)
                    {
                        // The trick here is to set these values to -1,
                        // And then later we can set them back easily.
                        curField[ptI] = -1;
                        // Info<< "Patch point on wall!" << endl;
                    }
                    else
                    {
                        minPatchToWallDist = VGREAT;
                        bool touched = 0;
                        for (label procI = 0; procI < Pstream::nProcs(); ++procI)
                        {
                            if (wallFaces[procI].size() != 0)
                            {
                                forAll(wallFaces[procI],faceI)
                                {
                                    pointField facePts = wallFaces[procI][faceI];

                                    if (wnPnPoly(hitPoint(shootPt,facePts),facePts))
                                    {
                                        scalar thisDist = hitDist(shootPt,facePts);
                                        if (thisDist < minPatchToWallDist)
                                        {
                                            minPatchToWallDist = thisDist;
                                            touched = 1;
                                        }
                                    }
                                }
                            }
                        }
                        // Use touched to prevent curField[ptI] = minPatchToWallDist
                        // Where minPatchToWallDist is still VGREAT
                        if (touched)
                        {
                            curField[ptI] = minPatchToWallDist;
                        }
                    }
                }

                forAll(currPatch.patch().faceCentres(), ptI)
                {
                    if (curField[ptI] == 0 || curField[ptI] != 0)
                    {
                        point shootPt = currPatch.patch().faceCentres()[ptI];
                        scalar minPatchToWallDist = VGREAT;
                        if (curField[ptI] != 0)
                        {
                            minPatchToWallDist = curField[ptI];
                        }
                        bool touched = 0;
                        for (label procI = 0; procI < Pstream::nProcs(); ++procI)
                        {
                            if (wallEdges[procI].size() != 0)
                            {
                                forAll(wallEdges[procI],edgeI)
                                {
                                    scalar tmpDist = ptInLine
                                    (
                                        shootPt,
                                        wallEdges[procI][edgeI][0],
                                        wallEdges[procI][edgeI][1]
                                    );
                                    if
                                    (
                                        mag(tmpDist-scalar(-1.0)) > VSMALL
                                     && tmpDist < minPatchToWallDist
                                    )
                                    {
                                        minPatchToWallDist = tmpDist;
                                        touched = 1;
                                    }
                                }
                            }
                        }
                        // Use touched to prevent curField[ptI] = minPatchToWallDist,
                        // Where minPatchToWallDist is still VGREAT
                        if (touched)
                        {
                            curField[ptI] = minPatchToWallDist;
                        }
                    }
                }

                forAll(currPatch.patch().faceCentres(), ptI)
                {
                    if (curField[ptI] == 0 || curField[ptI] != 0)
                    {
                        point shootPt = currPatch.patch().faceCentres()[ptI];
                        scalar minPatchToWallDist = VGREAT;
                        if (curField[ptI] != 0)
                        {
                            minPatchToWallDist = curField[ptI];
                        }
                        for (label procI = 0; procI < Pstream::nProcs(); ++procI)
                        {
                            if (wallPts[procI].size() != 0)
                            {
                                label minPtID = minDistPtID(shootPt,wallPts[procI]);
                                point minPt = wallPts[procI][minPtID];
                                if (mag(shootPt-minPt) < minPatchToWallDist)
                                {
                                    minPatchToWallDist = mag(shootPt-minPt);
                                }
                            }
                        }
                        curField[ptI] = minPatchToWallDist;
                    }
                }

                // Intersection points correction
                forAll(curField,ptI)
                {
                    if (curField[ptI] == -1)
                    {
                        curField[ptI] = VSMALL;
                    }
                }

                boundaryField()[patchI].transfer(curField);
            }
        }
    }
}


// ************************************************************************* //
